# Weather App

Simple single-page Weather App that uses WeatherAPI (https://www.weatherapi.com/) to fetch current weather.

## What's included
- `index.html` — the app HTML/CSS/JS.
- `config.example.js` — example config file showing where to place your API key.
- `.gitignore` — ignores `config.js` so you don't accidentally commit your key.

## Setup (local)
1. Sign up at https://www.weatherapi.com/ and get an API key.
2. Copy `config.example.js` to `config.js`:
   ```bash
   cp config.example.js config.js
   ```
3. Open `config.js` and replace `YOUR_WEATHERAPI_KEY_HERE` with your key.
4. Open `index.html` in your browser.

## Notes for GitHub
- This repo is ready to be pushed to GitHub. The `config.js` file is ignored so your API key won't be committed.
- GitHub Pages will serve the static `index.html`. If you want to use GitHub Pages, add `config.js` to the published repo (or configure the key via another method) — note: GitHub Pages is a static host and does not support secret environment variables for client-side JS.

## Security
Because this app runs entirely in the browser, the API key will be visible in network requests and browser devtools. For production use, implement a small server-side proxy to keep the API key secret.

## License
MIT

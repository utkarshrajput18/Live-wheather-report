// Copy this file to config.js and add your API key.
// Do NOT commit config.js to your repository.
window.WEATHER_API_KEY = "YOUR_WEATHERAPI_KEY_HERE";